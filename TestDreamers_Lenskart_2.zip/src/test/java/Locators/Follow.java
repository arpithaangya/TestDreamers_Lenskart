package Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Follow {
	
	@FindBy(xpath="//a[@href='https://www.facebook.com/Lenskartindia']") public WebElement facebook;
	
}
